import React from "react";

const Rental = () => {
  return <h1>Rental</h1>;
};

export default Rental;
